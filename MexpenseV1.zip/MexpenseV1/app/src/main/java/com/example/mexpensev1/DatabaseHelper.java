package com.example.mexpensev1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

class DatabaseHelper extends SQLiteOpenHelper {

    private final Context context;
    private static final String DATABASE_NAME = "mexpense.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_TRIP = "trip";
    private static final String COL_ID = "id";
    private static final String COL_NAME = "name";
    private static final String COL_DESTINATION = "destination";
    private static final String COL_TYPE= "type";
    private static final String COL_START_DATE = "start_date";
    private static final String COL_END_DATE = "end_date";
    private static final String COL_RISK = "risk";
    private static final String COL_IMPORTANT = "important";
    private static final String COL_DESCRIPTION = "description";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE IF NOT EXISTS " + TABLE_TRIP + " ( " +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_NAME + " TEXT NOT NULL," +
                COL_DESTINATION + " TEXT NOT NULL," +
                COL_TYPE + " TEXT NOT NULL," +
                COL_START_DATE + " TEXT NOT NULL," +
                COL_END_DATE + " TEXT NOT NULL," +
                COL_RISK + " INTEGER NOT NULL ," +
                COL_IMPORTANT + " INTEGER NOT NULL ," +
                COL_DESCRIPTION + " TEXT)";
        db.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRIP);
        onCreate(db);

    }

    void addTrip(String tripName, String destination, String type, String startdate, String enddate, int risk, int important,  String description){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_NAME, tripName);
        cv.put(COL_DESTINATION, destination);
        cv.put(COL_TYPE, type);
        cv.put(COL_START_DATE, startdate);
        cv.put(COL_END_DATE, enddate);
        cv.put(COL_RISK, risk);
        cv.put(COL_IMPORTANT, important);
        cv.put(COL_DESCRIPTION, description);
        long result = db.insert(TABLE_TRIP,null, cv);
        if(result == -1){
            Toast.makeText(context, "Failed", Toast.LENGTH_LONG).show();
        }else {
            Toast.makeText(context, "Added Successfully!", Toast.LENGTH_LONG).show();
        }
    }

    Cursor readAllTripData(){
        String query = "SELECT * FROM " + TABLE_TRIP;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

}
