package com.example.mexpensev1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView listTrip;
    FloatingActionButton btnAddTrip;
    DatabaseHelper myDB;
    ArrayList<String> trip_ID, trip_Name, trip_Startdate, trip_Enddate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listTrip    = findViewById(R.id.listTrip);
        btnAddTrip  = findViewById(R.id.btnAddTrip);
        btnAddTrip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddTripActivity.class);
                startActivity(intent);
            }
        });

        myDB = new DatabaseHelper(MainActivity.this);
        trip_ID = new ArrayList<>();
        trip_Name = new ArrayList<>();
        trip_Startdate = new ArrayList<>();
        trip_Enddate = new ArrayList<>();

        storeTripDataInArrays();

    }

    void storeTripDataInArrays(){
        Cursor cursor = myDB.readAllTripData();
        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Trip", Toast.LENGTH_LONG).show();
        }else{
            while (cursor.moveToNext()){
                trip_ID.add(cursor.getString(0));
                trip_Name.add(cursor.getString(1));
                trip_Startdate.add(cursor.getString(4));
                trip_Enddate.add(cursor.getString(5));
            }
        }
    }



}